from Labirynt.Algorytmy.BFS import BFS
from Labirynt.Algorytmy.wspolbiezny import Wspolbiezny
from Labirynt.Labirynt import Labirynt

if __name__ == "__main__":
    l = Labirynt(wiersze=10, kolumny=10, gestosc=0.3)
    l.wyswietl()

    # Sprawdzamy algorytm BFS
    print("== Wynik BFS ==")
    alg_bfs = BFS(l)
    print("Czy istnieje ścieżka?", alg_bfs.przeszukaj())

    # Sprawdzamy algorytm współbieżny
    print("\n== Wynik współbieżny ==")
    alg_wsp = Wspolbiezny(l)
    print("Czy istnieje ścieżka?", alg_wsp.przeszukaj())