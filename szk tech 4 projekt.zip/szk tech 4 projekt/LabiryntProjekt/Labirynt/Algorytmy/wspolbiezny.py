from multiprocessing import Pool

from Labirynt.Algorytmy.BFS import BFS
from Labirynt.Algorytmy.baza import AlgorytmBazowy
from Labirynt.dekoratory import timer, log


#funkcja uruchamiana w osobnych procesach, ktr=ora bierze args (luste argumentow - czyli u nas labirynt)
#dla kazdego procesu ta funkcja tworzy nowy obiekt bfs, uruchamia metode przeszukaj i zwraca wynik

def przeszukaj_fragment(args):
    # args to krotka zawierająca dwa elementy: labirynt oraz numer procesu
    labirynt, numer_procesu = args
    print(f"\n{'='*15} [Proces {numer_procesu}] START {'='*15}\n")
    # Tworzymy nowy obiekt BFS dla tego procesu, przekazując mu labirynt
    bfs = BFS(labirynt)
    # Uruchamiamy przeszukiwanie labiryntu algorytmem BFS
    wynik = bfs.przeszukaj()
    # Wypisujemy komunikat KONIEC z wynikiem (czy ścieżka istnieje) dla danego procesu (#!,2,3,4)
    print(f"\n{'='*15} [Proces {numer_procesu}] KONIEC — wynik: {wynik} {'='*15}\n")
    # Zwracamy wynik (True/False) do procesu GLOWNEGO
    return wynik
class Wspolbiezny(AlgorytmBazowy):
    @timer
    @log
    def przeszukaj(self):  #metoda wymuszona przez klase bazowa mataalgorytm
        liczba_procesow = 4 #tyle bedzie procesow rownoleglych uruchomoinych
        argumenty = [(self.labirynt, i+1) for i in range(liczba_procesow)] #to lista argumentów (tu: 4 razy ten sam labirynt)

        with Pool(liczba_procesow) as pool:
        #Pool uruchamia kilka procesów równolegle
            wyniki = pool.map(przeszukaj_fragment, argumenty)
        # Każdy proces uruchamia funkcję przeszukaj_fragment
        # Pool.map rozdziela listę argumentów na procesy

        # Wyniki to lista: np. [True, False, False, True]
        # any(wyniki) - jeśli choć jeden proces znalazł ścieżkę, zwracamy True
        return any(wyniki)