from collections import deque

from Labirynt.Algorytmy.baza import AlgorytmBazowy
from Labirynt.dekoratory import timer, log


class BFS(AlgorytmBazowy):
    @timer
    @log

    def przeszukaj(self):
        # przeszukuje labirynt algorytmem BFS i zwraca True,
        # jeśli istnieje ścieżka z lewego górnego rogu do prawego dolnego.

        # Pobieramy dane z labiryntu (wymiary i siatka)
        wiersze = self.labirynt.wiersze
        kolumny = self.labirynt.kolumny
        siatka = self.labirynt.siatka

        #to tablica odwiedzonych pol zeby nie wracac w kolko
        odwiedzone = [[False for _ in range(kolumny)] for _ in range(wiersze)]
        #kolejka do przeszukiwania
        kolejka = deque()
        kolejka.append((0,0)) #zaczynamy od 0,0
        odwiedzone[0][0] = True

        #lista mozliwych ruchow
        ruchy = [(-1,0), (1,0), (0,-1), (0,1)]

        #petla BFS DOPOKI KOLEJKA INE JEST PUSTA
        while kolejka:
            x, y = kolejka.popleft() #zdejmujemy z kolejki
            if(x, y) == (wiersze -1, kolumny -1): # if dodatrlismy na koniec
                print("[BFS] Znaleziono ścieżkę!")
                return True

            # Sprawdzamy wszystkie możliwe sąsiednie pola
            for dx, dy in ruchy:
                nx, ny = x + dx, y + dy
                # Czy pole w granicach i czy wolne (0) i nieodwiedzone
                if 0 <= nx < wiersze and 0 <= ny < kolumny:
                    if siatka[nx][ny] == 0 and not odwiedzone[nx][ny]:
                        odwiedzone[nx][ny] = True
                        kolejka.append((nx, ny))

            # Jeśli nie dotarliśmy do mety – brak ścieżki
        print("[BFS] Ścieżka NIE istnieje.")
        return False
