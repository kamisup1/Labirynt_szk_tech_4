import random
class Labirynt:
    def __init__(self, wiersze, kolumny, gestosc=0.3):
        self.wiersze = wiersze
        self.kolumny= kolumny
        self.gestosc= gestosc
        self.siatka = self._generuj()

    def _generuj(self):
        #Tworzy dwuwymiarową listę z losowo rozmieszczonymi ścianami
        siatka = [
            [1 if random.random() < self.gestosc else 0 for _ in range(self.kolumny)]
            for _ in range(self.wiersze)
        ]
        # Gwarantujemy, że start i meta są sawsze kropkami
        siatka[0][0] = 0
        siatka[self.wiersze - 1][self.kolumny - 1] = 0
        return siatka

    def wyswietl(self):
        #Wypisuje labirynt w konsoli w czytelnej formie
        for wiersz in self.siatka:
            linia = ''.join(['#' if pole == 1 else 'o' for pole in wiersz])
            print(linia)